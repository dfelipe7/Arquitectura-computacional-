var searchData=
[
  ['valuegas_0',['valuegas',['../sketch_8ino.html#a5df72edf268cd005807cb29d27e29f99',1,'sketch.ino']]],
  ['valueluz_1',['valueluz',['../sketch_8ino.html#aa3e4d96f2678ba92b12d8e31235700a2',1,'sketch.ino']]],
  ['valuetemp_2',['valuetemp',['../sketch_8ino.html#ab6d68968e12c1b3b9e01f5f6a730af14',1,'sketch.ino']]]
];
