var searchData=
[
  ['hall_0',['hall',['../sketch_8ino.html#af295e7dfa53e60f69899f2fd7133ce7e',1,'sketch.ino']]]
];
