var searchData=
[
  ['monitoreoamb_0',['monitoreoAmb',['../sketch_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8a51a3967eb852934c370767007193a587',1,'sketch.ino']]],
  ['monitoreoevent_1',['monitoreoEvent',['../sketch_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8abb704b68912235c0944d1ddee9df09a2',1,'sketch.ino']]]
];
