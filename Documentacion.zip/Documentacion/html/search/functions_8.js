var searchData=
[
  ['menu_0',['menu',['../sketch_8ino.html#a44326b98ec270b9c40bf1f2c7bbdbc72',1,'sketch.ino']]],
  ['menu_5fconfig_1',['menu_config',['../sketch_8ino.html#a18658883d764b47f372a3d40f552a44b',1,'sketch.ino']]],
  ['monitoreo_5famb_2',['monitoreo_amb',['../sketch_8ino.html#ad59320b8aee00bbe3da0161f4cfd58d7',1,'sketch.ino']]]
];
