var searchData=
[
  ['init_0',['INIT',['../sketch_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8a0cb1b2c6a7db1f1084886c98909a3f36',1,'sketch.ino']]]
];
