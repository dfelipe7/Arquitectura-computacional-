var searchData=
[
  ['bloqueado_0',['bloqueado',['../sketch_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8a2a75188bc33c8ddd33c0d22fcdae029b',1,'sketch.ino']]],
  ['bloqueo_1',['bloqueo',['../sketch_8ino.html#a080a822f0093973313bd644e517a5090a1fb0ec8186e09ac8e7580e2de58618f0',1,'sketch.ino']]],
  ['btn_5fpress_2',['btn_Press',['../sketch_8ino.html#a080a822f0093973313bd644e517a5090aed3f0f51193ea916d6cae7ccf6b1be36',1,'sketch.ino']]]
];
