var searchData=
[
  ['desconocido_0',['desconocido',['../sketch_8ino.html#a080a822f0093973313bd644e517a5090a098f566f273b9d4eef0258bbccea96d4',1,'sketch.ino']]]
];
