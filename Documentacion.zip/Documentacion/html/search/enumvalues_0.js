var searchData=
[
  ['alarma_0',['alarma',['../sketch_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8a87cab433798ce5fdc94e2f76739e7bb5',1,'sketch.ino']]]
];
