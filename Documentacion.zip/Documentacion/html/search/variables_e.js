var searchData=
[
  ['taskgas_0',['TaskGas',['../sketch_8ino.html#a12d2d2e4e3c64c53ebd22a83ded5b7ef',1,'sketch.ino']]],
  ['taskluz_1',['TaskLuz',['../sketch_8ino.html#adf89cba379f2c91d48bce89b7b028241',1,'sketch.ino']]],
  ['taskretorno_2',['TaskRetorno',['../sketch_8ino.html#a5ddbc597fc6dc951f2486067dc37750c',1,'sketch.ino']]],
  ['tasktemp_3',['TaskTemp',['../sketch_8ino.html#a7fa8fbe476c15d2988832430479321b8',1,'sketch.ino']]],
  ['temperatura_4',['temperatura',['../sketch_8ino.html#a6a2fb9a759add5686a3738d8b00fac9a',1,'sketch.ino']]],
  ['temphigh_5',['tempHigh',['../sketch_8ino.html#a6a1e4720fd7bbd1f81bebf1b3de0efec',1,'sketch.ino']]],
  ['templow_6',['tempLow',['../sketch_8ino.html#a94903018690fcd7ea22fe857aee17107',1,'sketch.ino']]]
];
