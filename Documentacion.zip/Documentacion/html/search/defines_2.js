var searchData=
[
  ['pin_5fbutton_0',['PIN_BUTTON',['../sketch_8ino.html#a3be8154d350ce65f5e6c1dfc284700af',1,'sketch.ino']]],
  ['pin_5fgas_1',['PIN_GAS',['../sketch_8ino.html#a20a222f0bf8c10df5b1748645a446413',1,'sketch.ino']]],
  ['pin_5fluz_2',['PIN_LUZ',['../sketch_8ino.html#a456010749e02571badfd3c3741165fd8',1,'PIN_LUZ:&#160;sketch.ino'],['../sketch_8ino.html#a456010749e02571badfd3c3741165fd8',1,'PIN_LUZ:&#160;sketch.ino']]],
  ['pin_5ftemyhum_3',['PIN_TEMYHUM',['../sketch_8ino.html#a1fb30984d794cbb3ae0beb7b53193e22',1,'sketch.ino']]]
];
