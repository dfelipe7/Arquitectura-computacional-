var searchData=
[
  ['clavecorrecta_0',['claveCorrecta',['../sketch_8ino.html#a080a822f0093973313bd644e517a5090abda7e67e4a52f6bee40c1949024922cd',1,'sketch.ino']]],
  ['config_1',['config',['../sketch_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8ab24e4a61d95cef52b430c0fabaa13834',1,'sketch.ino']]]
];
